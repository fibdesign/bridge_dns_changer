export const MODELS:{[key:string]:any} = {
    Article: 'App\\Models\\Article',
    Product: 'App\\Models\\Product',
}