const CATEGORIES_KEYS = {
    ARTICLES: 'Articles',
    CLIENTS: 'Clients',
    PRODUCTS: 'Products',
    BASICS: 'Basics'
}
export default CATEGORIES_KEYS