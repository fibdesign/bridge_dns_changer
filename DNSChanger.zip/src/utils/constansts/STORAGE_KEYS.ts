const STORAGE_KEYS = {
    THEME: 'theme',
    USER: 'user',
    TOKEN: 'token',
    LOCALIZATION: 'locale',
    CART: 'anonymousCart'
}
export default STORAGE_KEYS