const enum CURRENCY_SINGS {
    TOOMAN = "تومان",
    RIAL = "ریال"
}
export default CURRENCY_SINGS