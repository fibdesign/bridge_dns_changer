export enum TRANSACTION_STATUS {
    PENDING,
    SUCCESSFUL,
    FAILED,
}
export enum TRANSACTION_STATUS_TITLE {
     'پرداخت نشده',
     'موفق',
     'ناموفق',
}