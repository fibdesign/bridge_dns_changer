export enum INVOICE_TYPES {
    ECOMMERCE
}