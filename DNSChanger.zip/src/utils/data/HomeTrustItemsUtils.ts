const HomeTrustItemsUtils = [
    {
        title: 'homeTrustCards.authenticity.title',
        subtitle: 'homeTrustCards.authenticity.subtitle',
        image: 'authenticity'
    },
    {
        title: 'homeTrustCards.truck.title',
        subtitle: 'homeTrustCards.truck.subtitle',
        image: 'truck'
    },
    {
        title: 'homeTrustCards.shovel.title',
        subtitle: 'homeTrustCards.shovel.subtitle',
        image: 'shovel'
    },
    {
        title: 'homeTrustCards.paymentProtection.title',
        subtitle: 'homeTrustCards.paymentProtection.subtitle',
        image: 'paymentProtection'
    },
]
export default HomeTrustItemsUtils