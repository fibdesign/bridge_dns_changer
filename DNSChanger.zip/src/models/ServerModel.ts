export interface ServerModel {
    id: number,
    title: string,
    description: string,
    image: string,
    dns1: string,
    dns2?: string,
}