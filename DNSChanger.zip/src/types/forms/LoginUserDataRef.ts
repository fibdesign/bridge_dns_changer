export default interface LoginUserDataRef {
    phone?: string,
    email?: string,
    password: string
}