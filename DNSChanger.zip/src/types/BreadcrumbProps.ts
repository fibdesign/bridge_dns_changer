export default interface BreadcrumbProps {
    title: string,
    to?: any
}