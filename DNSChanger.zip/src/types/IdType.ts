import type {LocationQueryValue} from "vue-router";

export type IdType = string|string[]|number|LocationQueryValue|LocationQueryValue[]
