export interface SimpleSeoProps {
  title: string,
  url: string
}