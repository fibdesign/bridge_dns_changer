export default interface DateOptionsType {
    time?: boolean,
    week?: boolean,
    date?: boolean,
    locale?: Intl.LocalesArgument
}