export default interface CurrencyOptionsType {
    isRial: boolean,
    locale: string,
    hasSign: boolean,
    sign: string
}