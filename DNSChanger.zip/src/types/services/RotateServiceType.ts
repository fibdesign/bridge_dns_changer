import type {Ref} from "vue";

export default interface RotateServiceType {
    element: Ref,
    speed?: number
}